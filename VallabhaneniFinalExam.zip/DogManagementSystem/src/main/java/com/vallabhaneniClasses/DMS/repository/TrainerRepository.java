package com.vallabhaneniClasses.DMS.repository;

import org.springframework.data.repository.CrudRepository;

import com.vallabhaneniClasses.DMS.models.Trainer;

public interface TrainerRepository extends  CrudRepository<Trainer, Integer> {

}
